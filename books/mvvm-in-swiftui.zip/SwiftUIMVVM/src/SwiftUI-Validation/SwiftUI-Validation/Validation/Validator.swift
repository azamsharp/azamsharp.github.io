//
//  Validator.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 2/11/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

class ValidationBase: ObservableObject {
    @Published fileprivate (set) var brokenRules: [BrokenRule] = [BrokenRule]()
}

protocol Validator: ValidationBase {
    func validate()  
}

extension Validator {
    
    func addBrokenRule(_ rule: BrokenRule) {
        brokenRules.append(rule)
    }
    
    func clearBrokenRules() {
        brokenRules = [] 
    }
    
}
