//
//  BrokenRule.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 2/11/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

struct BrokenRule {
    let id = UUID()
    let name: String
    let message: String
}
