//
//  ContentView.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 2/11/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject private var registrationVM = RegistrationViewModel()
    
    var body: some View {
        NavigationView {
            
            Form {
                VStack(spacing: 10) {
                    TextField("First name", text: $registrationVM.firstname)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Last name", text: $registrationVM.lastname)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Username", text: $registrationVM.username)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Password", text: $registrationVM.password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button("Register") {
                        
                        self.registrationVM.validate()
                        
                    }.padding(10)
                        .background(Color.blue)
                        .cornerRadius(6)
                        .foregroundColor(Color.white)
                    
                    BrokenRulesView(brokenRules: registrationVM.brokenRules)
                    
                }
            }
            .navigationBarTitle("Registration")
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
