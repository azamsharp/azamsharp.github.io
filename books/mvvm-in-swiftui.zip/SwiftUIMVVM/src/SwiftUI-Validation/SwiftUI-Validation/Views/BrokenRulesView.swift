//
//  BrokenRulesView.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 2/11/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct BrokenRulesView: View {
    
    let brokenRules: [BrokenRule]
    
    var body: some View {
        List(brokenRules, id: \.id) { rule in
            Text(rule.message)
        }
    }
}

struct BrokenRulesView_Previews: PreviewProvider {
    static var previews: some View {
        BrokenRulesView(brokenRules: [])
    }
}
