//
//  RegistrationViewModel.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 2/11/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

class RegistrationViewModel: ValidationBase {
    var firstname: String = ""
    var lastname: String = ""
    var username: String = ""
    var password: String = ""
}

extension RegistrationViewModel: Validator {
    
    func validate() {
        
        clearBrokenRules() 
        
        if firstname.isEmpty {
            addBrokenRule(BrokenRule(name: "firstname", message: "Firstname should not be empty"))
        }
        
        if(lastname.isEmpty) {
            addBrokenRule(BrokenRule(name: "lastname", message: "Lastname should not be empty"))
        }
        
    }
}
