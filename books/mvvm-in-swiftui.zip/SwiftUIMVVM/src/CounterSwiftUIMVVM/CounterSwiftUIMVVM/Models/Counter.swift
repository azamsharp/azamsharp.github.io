//
//  Counter.swift
//  CounterSwiftUIMVVM
//
//  Created by Mohammad Azam on 1/27/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

struct Counter {
    
    var value: Int
    
    mutating func increment() {
        value += 1
    }
    
    mutating func decrement()  {
        value -= 1
    }
    
    
}
