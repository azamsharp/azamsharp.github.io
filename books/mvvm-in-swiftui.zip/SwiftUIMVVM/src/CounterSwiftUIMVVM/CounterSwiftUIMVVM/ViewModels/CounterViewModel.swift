//
//  CounterViewModel.swift
//  CounterSwiftUIMVVM
//
//  Created by Mohammad Azam on 1/18/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

class CounterViewModel: ObservableObject {
    
    @Published var counter: Counter = Counter(value: 0)
    
    var value: Int {
        return self.counter.value
    }
    
    func increment() {
        self.counter.increment()
    }
    
    func decrement() {
        self.counter.decrement()
    }
}
