//
//  ContentView.swift
//  CounterSwiftUIMVVM
//
//  Created by Mohammad Azam on 1/18/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject private var counterVM: CounterViewModel = CounterViewModel()
    
    var body: some View {
        VStack {
            Text("\(self.counterVM.value)")
            
            HStack {
                Button("Increment") {
                    self.counterVM.increment()
                }
                Button("Decrement") {
                    self.counterVM.decrement()
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
