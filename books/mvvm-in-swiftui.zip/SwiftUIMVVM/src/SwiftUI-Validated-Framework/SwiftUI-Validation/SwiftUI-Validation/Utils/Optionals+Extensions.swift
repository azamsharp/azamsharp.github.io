//
//  Optionals+Extensions.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 3/2/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

extension Optional where Wrapped == String {
    var _bound: String? {
        get {
            return self
        }
        set {
            self = newValue
        }
    }
    public var bound: String {
        get {
            return _bound ?? ""
        }
        set {
            _bound = newValue.isEmpty ? nil : newValue
        }
    }
}
