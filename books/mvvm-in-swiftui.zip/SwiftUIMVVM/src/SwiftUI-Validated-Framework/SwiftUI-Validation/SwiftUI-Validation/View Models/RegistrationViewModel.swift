//
//  RegistrationViewModel.swift
//  SwiftUI-Validation
//
//  Created by Mohammad Azam on 2/11/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation
import ValidatedPropertyKit

class RegistrationViewModel: ObservableObject {
    
    @Validated(.required(errorMessage: "First name cannot be empty"))
    var firstname: String? = ""
    
    @Validated(.required(errorMessage: "Last name cannot be empty"))
    var lastname: String? = ""
    
    @Validated(.required(errorMessage: "Username cannot be empty"))
    var username: String? = ""
    
    @Validated(.required(errorMessage: "Password cannot be empty"))
    var password: String? = ""
    
    @Published private (set) var brokenRules: [BrokenRule] = [BrokenRule]()
    
    func validate()  {
        
        // clear the broken rules
        brokenRules.removeAll()
        
        let rules = [
            "Firstname": _firstname.validationError,
            "Lastname": _lastname.validationError,
            "Username": _username.validationError,
            "Password": _password.validationError
        ]
        
        _ = rules.compactMap { pair -> Void in
            
            guard let errorMessage = pair.1?.failureReason else { return  }
            brokenRules.append(BrokenRule(name: pair.0, message: errorMessage))
        }
    }
}
