//
//  Stock.swift
//  networking-mvvm
//
//  Created by Mohammad Azam on 1/21/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

struct Stock: Decodable {
    let symbol: String
    let price: Double
    let description: String
    let change: String 
}
