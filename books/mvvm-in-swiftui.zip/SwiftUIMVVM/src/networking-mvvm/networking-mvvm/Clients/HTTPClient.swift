//
//  HTTPClient.swift
//  networking-mvvm
//
//  Created by Mohammad Azam on 1/21/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

enum NetworkError: Error {
    case invalidURL
    case unknownError
    case decodingError
}

class HTTPClient {
    
    func getAllStocks(urlString: String, completion: @escaping (Result<[Stock],NetworkError>) -> Void) {
        
        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard let data = data, error == nil else {
                completion(.failure(.unknownError))
                return
            }
            
            let stocks = try? JSONDecoder().decode([Stock].self, from: data)
            stocks == nil ? completion(.failure(.decodingError)) : completion(.success(stocks!))
            
        }.resume()
    }
    
}
