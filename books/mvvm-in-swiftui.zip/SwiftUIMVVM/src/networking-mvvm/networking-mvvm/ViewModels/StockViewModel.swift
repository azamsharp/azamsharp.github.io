//
//  StockViewModel.swift
//  networking-mvvm
//
//  Created by Mohammad Azam on 1/21/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

class StockListViewModel {
    
    var stocks = [StockViewModel]()
    
    func fetchAllStocks() {
        
        HTTPClient().getAllStocks(urlString: "https://silicon-rhinoceros.glitch.me/stocks") { result in
            DispatchQueue.main.async {
                switch result {
                    case .success(let stocks):
                        self.stocks = stocks.map(StockViewModel.init)
                    case .failure(let error):
                        print(error.localizedDescription)

                }
            }
            
        }
        
    }
}

struct StockViewModel {
    
    let stock: Stock
    
    init(stock: Stock) {
        self.stock = stock 
    }
    
    var symbol: String {
        return self.stock.symbol.uppercased()
    }
    
    var description: String {
        return self.stock.description
    }
    
    var price: String {
        return String(format: "%.2f",self.stock.price)
    }
    
    var change: String {
        return self.stock.change
    }
    
}
